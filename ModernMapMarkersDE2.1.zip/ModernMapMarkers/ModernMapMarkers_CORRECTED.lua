-- KORRIGIERTE POINTS-TABELLE FÜR MODERNMAPMARKERS
-- Ersetze die 'local points = {...}' Tabelle in ModernMapMarkers.lua mit diesem Inhalt
--
-- KORREKTUREN:
-- 1. Zeile 69: "Ruine von Sturmschmied" von Zone 9 (Dun Morogh) nach Zone 4 (Balor) verschoben
-- 2. Zeppelin-Einträge für Durotar (Zone 7) hinzugefügt (sichtbar von Durotar aus)
-- 3. Mulgore-Eintrag (Zone 20) für Donnerfels-Zeppelin hinzugefügt

local points = {
    -- Kalimdor Dungeons
    {1, 11, 0.123, 0.128, "Tiefschwarze Grotte", "dungeon", "24-32", 2},
    {1, 25, 0.66, 0.49, "Der Schwarze Morast", "dungeon", "60", 1},
    {1, 11, 0.51, 0.78, "Mondsichelhain", "dungeon", "32-38", 3},
    {1, 12, 0.648, 0.303, "Düsterbruch - Ost", "dungeon", "55-58", 4},
    {1, 12, 0.624, 0.249, "Düsterbruch - Nord", "dungeon", "57-60", 5},
    {1, 12, 0.604, 0.311, "Düsterbruch - West", "dungeon", "57-60", 6},
    {1, 4, 0.29, 0.629, "Maraudon", "dungeon", "46-55", 8},
    {1, 21, 0.53, 0.486, "Der Flammenschlund", "dungeon", "13-18", 10},
    {1, 2, 0.488, 0.919, "Hügel der Klingenhauer", "dungeon", "37-46", 11},
    {1, 2, 0.407, 0.873, "Kral der Klingenhauer", "dungeon", "29-38", 12},
    {1, 2, 0.462, 0.357, "Höhlen des Wehklagens", "dungeon", "17-24", 15},
    {1, 25, 0.389, 0.184, "Zul'Farrak", "dungeon", "44-54", 16},
    -- Kalimdor Raids
    {1, 9, 0.207, 0.592, "Smaragdsanktum", "raid", "60", 7},
    {1, 9, 0.53, 0.76, "Onyxias Hort", "raid", "60", 9},
    {1, 23, 0.296, 0.960, "Ruinen von Ahn'Qiraj", "raid", "60", 13},
    {1, 23, 0.282, 0.956, "Tempel von Ahn'Qiraj", "raid", "60", 14},
    -- Kalimdor World Bosses
    {1, 1, 0.535, 0.816, "Azuregos", "worldboss", "60", nil},
    {1, 1, 0.69, 0.094, "Cla'ckora", "worldboss", "60", nil},
    {1, 4, 0.82, 0.80, "Concavius", "worldboss", "60"},
    {1, 9, 0.336, 0.398, "Vater Lykan", "worldboss", "60", nil},
    {1, 25, 0.361, 0.762, "Ostarius", "worldboss", "60", nil},
    {1, 11, 0.937, 0.355, "Smaragddrache - Spawnpunkt 1 von 4", "worldboss", "60", nil},
    {1, 12, 0.512, 0.108, "Smaragddrache - Spawnpunkt 2 von 4", "worldboss", "60", nil},
    -- Kalimdor Transport
    -- Orgrimmar Zeppeline (Zone 21)
    {1, 21, 0.512, 0.135, "Zeppeline nach Unterstadt & Grom'Gol", "zepp", "Horde", nil},
    {1, 21, 0.415, 0.184, "Zeppeline nach Donnerfels & Kargath", "zepp", "Horde", nil},
    -- Durotar Zeppeline (Zone 7) - HINZUGEFÜGT: Sichtbar von Durotar aus
    {1, 7, 0.50, 0.06, "Zeppeline nach Unterstadt & Grom'Gol", "zepp", "Horde", nil},
    {1, 7, 0.42, 0.08, "Zeppeline nach Donnerfels & Kargath", "zepp", "Horde", nil},
    -- Donnerfels Zeppelin (Zone 5)
    {1, 5, 0.165, 0.230, "Zeppelin nach Orgrimmar", "zepp", "Horde", nil},
    -- Mulgore Zeppelin (Zone 20) - HINZUGEFÜGT: Sichtbar von Mulgore aus
    {1, 20, 0.47, 0.05, "Zeppelin nach Orgrimmar", "zepp", "Horde", nil},
    -- Boote
    {1, 21, 0.598, 0.236, "Boot nach Rächer-Trolldorf", "boat", "Horde", nil},
    {1, 2, 0.636, 0.389, "Boot nach Beutebucht", "boat", "Neutral", nil},
    {1, 6, 0.324, 0.44, "Boot nach Sturmwind", "boat", "Allianz", nil},
    {1, 6, 0.304, 0.41, "Boot nach Alah'Thalas", "boat", "Allianz", nil},
    {1, 6, 0.333, 0.399, "Boot nach Rut'theran", "boat", "Allianz", nil},
    {1, 9, 0.718, 0.566, "Boot nach Menethil", "boat", "Allianz", nil},
    {1, 12, 0.311, 0.395, "Boot zur Vergessenen Küste", "boat", "Allianz", nil},
    {1, 12, 0.431, 0.428, "Boot zur Sardorinsel", "boat", "Allianz", nil},
    {1, 6, 0.552, 0.949, "Boot nach Auberdine", "boat", "Allianz", nil},
    -- Eastern Kingdoms Dungeons
    {2, 24, 0.371, 0.857, "Schwarzfelstiefen", "dungeon", "52-60", 1},
    {2, 5, 0.328, 0.362, "Schwarzfelstiefen", "dungeon", "52-60", 1},
    {2, 36, 0.423, 0.726, "Die Todesminen", "dungeon", "17-24", 3},
    {2, 15, 0.30, 0.27, "Gilneas", "dungeon", "43", 5},
    {2, 9, 0.248, 0.337, "Gnomeregan", "dungeon", "29-38", 6},
    {2, 5, 0.95, 0.53, "Steinbruch der Hassschmiede", "dungeon", "52-60", 7},
    {2, 13, 0.45, 0.75, "Karazhan Krypta", "dungeon", "58-60", 8},
    {2, 5, 0.321, 0.386, "Untere Schwarzfelsspitze", "dungeon", "55-60", 9},
    {2, 24, 0.364, 0.879, "Untere Schwarzfelsspitze", "dungeon", "55-60", 9},
    {2, 30, 0.869, 0.323, "Scharlachrotes Kloster - Waffenkammer", "dungeon", "32-42", 13},
    {2, 30, 0.862, 0.295, "Scharlachrotes Kloster - Kathedrale", "dungeon", "35-45", 14},
    {2, 30, 0.839, 0.283, "Scharlachrotes Kloster - Friedhof", "dungeon", "26-36", 15},
    {2, 30, 0.850, 0.338, "Scharlachrotes Kloster - Bibliothek", "dungeon", "29-39", 16},
    {2, 37, 0.69, 0.74, "Scholomance", "dungeon", "58-60", 17},
    {2, 25, 0.44, 0.67, "Burg Schattenfang", "dungeon", "22-30", 18},
    {2, 26, 0.51, 0.675, "Das Verlies", "dungeon", "24-31", 19},
    {2, 26, 0.63, 0.58, "Gewölbe von Sturmwind", "dungeon", "60", 20},
    {2, 35, 0.29, 0.61, "Gewölbe von Sturmwind - Horde-Eingang", "dungeon", "60", 20},
    {2, 39, 0.31, 0.14, "Stratholme", "dungeon", "58-60", 22},
    {2, 39, 0.47, 0.24, "Stratholme - Hintereingang", "dungeon", "58-60", 22},
    {2, 28, 0.701, 0.55, "Der Versunkene Tempel", "dungeon", "50-60", 23},
    {2, 38, 0.429, 0.130, "Uldaman - Haupteingang", "dungeon", "41-51", 25},
    {2, 38, 0.657, 0.438, "Uldaman - Hintereingang", "dungeon", "41-51", 25},
    {2, 5, 0.312, 0.365, "Obere Schwarzfelsspitze", "dungeon", "55-60", 26},
    {2, 24, 0.355, 0.855, "Obere Schwarzfelsspitze", "dungeon", "55-60", 26},
    {2, 27, 0.67, 0.634, "Drachenmal Zuflucht", "dungeon", "27-33", 4},
    -- KORRIGIERT: Ruine von Sturmschmied jetzt in Zone 4 (Balor) statt Zone 9 (Dun Morogh)
    {2, 4, 0.57, 0.598, "Ruine von Sturmschmied", "dungeon", "35-41", 21},
    -- Eastern Kingdoms Raids
    {2, 24, 0.332, 0.851, "Pechschwingenhort", "raid", "60", 2},
    {2, 5, 0.273, 0.363, "Pechschwingenhort", "raid", "60", 2},
    {2, 13, 0.46, 0.70, "Untere Hallen von Karazhan", "raid", "58-60", 10},
    {2, 24, 0.336, 0.879, "Geschmolzener Kern", "raid", "60", 11},
    {2, 5, 0.273, 0.387, "Geschmolzener Kern", "raid", "60", 11},
    {2, 39, 0.40, 0.28, "Naxxramas", "raid", "60", 12},
    {2, 13, 0.442, 0.719, "Turm von Karazhan", "raid", "60", 24},
    {2, 23, 0.53, 0.172, "Zul'Gurub", "raid", "60", 27},
    -- Eastern Kingdoms World Bosses
    {2, 13, 0.471, 0.751, "Dunkler Räuber von Karazhan", "worldboss", "60", nil},
    {2, 10, 0.465, 0.357, "Smaragddrache - Spawnpunkt 3 von 4", "worldboss", "60", nil},
    {2, 17, 0.632, 0.217, "Smaragddrache - Spawnpunkt 4 von 4", "worldboss", "60", nil},
    {2, 33, 0.36, 0.753, "Lord Kazzak", "worldboss", "60", 7},
    {2, 39, 0.082, 0.38, "Nerubischer Aufseher", "worldboss", "60", nil},
    -- Eastern Kingdoms Transport
    {2, 26, 0.694, 0.294, "Tiefenbahn nach Eisenschmiede", "tram", "Allianz", nil},
    {2, 12, 0.762, 0.511, "Tiefenbahn nach Sturmwind", "tram", "Allianz", nil},
    {2, 17, 0.812, 0.794, "Boot nach Funkelwasserhafen", "boat", "Horde", nil},
    {2, 27, 0.068, 0.613, "Boot nach Theramore", "boat", "Allianz", nil},
    {2, 26, 0.218, 0.563, "Boot nach Auberdine", "boat", "Allianz", nil},
    {2, 23, 0.257, 0.73, "Boot nach Ratschet", "boat", "Neutral", nil},
    -- Tirisfal Zeppeline (Zone 30)
    {2, 30, 0.616, 0.571, "Zeppeline nach Orgrimmar & Grom'Gol", "zepp", "Horde", nil},
    -- HINZUGEFÜGT: Unterstadt Zeppeline (Zone 32) - Sichtbar von Unterstadt aus
    {2, 32, 0.616, 0.571, "Zeppeline nach Orgrimmar & Grom'Gol", "zepp", "Horde", nil},
    -- Schlingendorntal Zeppeline (Zone 23)
    {2, 23, 0.312, 0.298, "Zeppeline nach Unterstadt & Orgrimmar", "zepp", "Horde", nil},
    -- Kargath Zeppelin
    {2, 38, 0.075, 0.480, "Zeppelin nach Orgrimmar", "zepp", "Horde", nil},
    {2, 27, 0.531, 0.047, "Boot nach Auberdine", "boat", "Allianz", nil},
}
